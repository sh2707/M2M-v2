namespace M2M_Receiver;

static class Program
{
    [STAThread]
    static void Main()
    {
        // only one copy of the app may run (same as the old M2M_Receiver_1)
        using var mutex = new Mutex(true, "M2M_Receiver_1_SingleInstance", out bool isFirst);
        if (!isFirst)
        {
            MessageBox.Show("You can't open this APP because it has already been open !!!", "Tip",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
