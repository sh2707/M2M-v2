using System.Text;
using System.Text.RegularExpressions;

namespace M2M_Receiver;

/// <summary>One record of a DB\yyyy-MM-dd.udb file:  "timestamp|content".</summary>
public sealed class DbRecord
{
    public DateTime Time { get; init; }
    public string Content { get; init; } = "";
    public string File { get; init; } = "";
}

/// <summary>Reads the daily .udb files written by the Receiver (old and new format are the same).</summary>
public static class DbReader
{
    private static readonly Regex StartRx = new(@"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d{3})\|", RegexOptions.Multiline | RegexOptions.Compiled);

    public static string FileFor(string dbDir, DateTime day) => Path.Combine(dbDir, day.ToString("yyyy-MM-dd") + ".udb");

    public static List<DbRecord> ReadFile(string path)
    {
        var list = new List<DbRecord>();
        if (!File.Exists(path)) return list;

        string text;
        using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
        using (var sr = new StreamReader(fs, Encoding.UTF8, true))
            text = sr.ReadToEnd();

        MatchCollection ms = StartRx.Matches(text);
        for (int i = 0; i < ms.Count; i++)
        {
            int start = ms[i].Index + ms[i].Length;
            int end = i + 1 < ms.Count ? ms[i + 1].Index : text.Length;
            string content = text.Substring(start, end - start).TrimEnd('\r', '\n');

            if (!DateTime.TryParseExact(ms[i].Groups[1].Value, "yyyy-MM-dd HH:mm:ss.fff",
                    System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out DateTime t))
                continue;

            list.Add(new DbRecord { Time = t, Content = content, File = Path.GetFileName(path) });
        }
        return list;
    }

    public static int CountRecords(string path)
    {
        try { return ReadFile(path).Count; }
        catch { return 0; }
    }

    /// <summary>Searches one day, or every .udb file. Empty filter = everything.</summary>
    public static List<DbRecord> Search(string dbDir, DateTime? day, string filter)
    {
        var result = new List<DbRecord>();
        if (!Directory.Exists(dbDir)) return result;

        IEnumerable<string> files = day.HasValue
            ? new[] { FileFor(dbDir, day.Value) }
            : Directory.GetFiles(dbDir, "*.udb").OrderBy(f => f, StringComparer.OrdinalIgnoreCase);

        foreach (string f in files)
        {
            foreach (DbRecord r in ReadFile(f))
            {
                if (filter.Length == 0 || r.Content.Contains(filter, StringComparison.OrdinalIgnoreCase))
                    result.Add(r);
            }
        }
        return result;
    }
}
