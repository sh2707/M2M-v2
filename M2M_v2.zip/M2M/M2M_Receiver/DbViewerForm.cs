using System.Text;

namespace M2M_Receiver;

/// <summary>Search window for the DB\*.udb files: by date and/or text, with CSV export.</summary>
public sealed class DbViewerForm : Form
{
    private const int MaxRows = 5000;

    private readonly string dbDir;
    private readonly DateTimePicker dtp = new() { Format = DateTimePickerFormat.Short, Width = 110 };
    private readonly CheckBox chkAllDates = new() { Text = "All dates", AutoSize = true, Margin = new Padding(8, 6, 8, 0) };
    private readonly TextBox txtFilter = new() { Width = 260 };
    private readonly Button btnSearch = new() { Text = "Search", Width = 80 };
    private readonly Button btnExport = new() { Text = "Export CSV...", Width = 100 };
    private readonly Label lblCount = new() { AutoSize = true, Margin = new Padding(12, 7, 0, 0), Text = "" };
    private readonly ListView lv = new() { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, GridLines = true };
    private readonly TextBox txtDetail = new()
    {
        Dock = DockStyle.Bottom,
        Height = 150,
        Multiline = true,
        ReadOnly = true,
        ScrollBars = ScrollBars.Both,
        WordWrap = false,
        Font = new Font("Consolas", 10)
    };

    private List<DbRecord> shown = new();

    public DbViewerForm(string dbDirectory)
    {
        dbDir = dbDirectory;
        Text = "DB Search";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(980, 600);
        MinimumSize = new Size(700, 400);

        lv.Columns.Add("Date / time", 160);
        lv.Columns.Add("Content", 780);

        var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(6, 6, 6, 0) };
        top.Controls.Add(new Label { Text = "Date", AutoSize = true, Margin = new Padding(0, 7, 4, 0) });
        top.Controls.Add(dtp);
        top.Controls.Add(chkAllDates);
        top.Controls.Add(new Label { Text = "Text", AutoSize = true, Margin = new Padding(8, 7, 4, 0) });
        top.Controls.Add(txtFilter);
        top.Controls.Add(btnSearch);
        top.Controls.Add(btnExport);
        top.Controls.Add(lblCount);

        // dock order: the control added last is laid out first
        Controls.Add(lv);
        Controls.Add(txtDetail);
        Controls.Add(top);

        AcceptButton = btnSearch;
        chkAllDates.CheckedChanged += (_, _) => dtp.Enabled = !chkAllDates.Checked;
        btnSearch.Click += async (_, _) => await RunSearchAsync();
        btnExport.Click += (_, _) => ExportCsv();
        lv.SelectedIndexChanged += (_, _) => ShowDetail();
        Shown += async (_, _) => await RunSearchAsync();
    }

    private async Task RunSearchAsync()
    {
        btnSearch.Enabled = false;
        lblCount.Text = "Searching ...";
        try
        {
            string filter = txtFilter.Text.Trim();
            DateTime? day = chkAllDates.Checked ? null : dtp.Value.Date;
            List<DbRecord> found = await Task.Run(() => DbReader.Search(dbDir, day, filter));

            shown = found.Count > MaxRows ? found.GetRange(0, MaxRows) : found;

            lv.BeginUpdate();
            lv.Items.Clear();
            foreach (DbRecord r in shown)
                lv.Items.Add(new ListViewItem(new[] { r.Time.ToString("yyyy-MM-dd HH:mm:ss.fff"), Flatten(r.Content) }));
            lv.EndUpdate();
            txtDetail.Text = "";

            lblCount.Text = found.Count > MaxRows
                ? $"{found.Count} records found - first {MaxRows} shown (narrow the search, or Export CSV for all)"
                : $"{found.Count} record(s) found";
            lastFound = found;
        }
        catch (Exception ex)
        {
            lblCount.Text = "Search failed: " + ex.Message;
        }
        finally
        {
            btnSearch.Enabled = true;
        }
    }

    private List<DbRecord> lastFound = new();

    private static string Flatten(string s) => s.Replace("\r", "").Replace("\n", " | ");

    private void ShowDetail()
    {
        if (lv.SelectedIndices.Count == 0) { txtDetail.Text = ""; return; }
        int i = lv.SelectedIndices[0];
        if (i < 0 || i >= shown.Count) return;
        txtDetail.Text = shown[i].Content.Replace("\r\n", "\n").Replace("\n", "\r\n");
    }

    private void ExportCsv()
    {
        if (lastFound.Count == 0)
        {
            MessageBox.Show(this, "Nothing to export. Search first.", "DB Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var dlg = new SaveFileDialog
        {
            Title = "Export search result",
            Filter = "CSV file (*.csv)|*.csv",
            FileName = "M2M_DB_Export_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv"
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            var sb = new StringBuilder();
            sb.Append("Time,Content\r\n");
            foreach (DbRecord r in lastFound)
                sb.Append(r.Time.ToString("yyyy-MM-dd HH:mm:ss.fff")).Append(",\"").Append(r.Content.Replace("\"", "\"\"")).Append("\"\r\n");
            File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
            MessageBox.Show(this, $"{lastFound.Count} record(s) exported.", "DB Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Export failed: " + ex.Message, "DB Search", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
