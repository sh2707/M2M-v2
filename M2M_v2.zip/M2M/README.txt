=====================================================================================
VERSION 2  (2026-10-27)  - what is new in this zip
=====================================================================================

CHECKED FIRST (your M2M_Receiver_1.zip)
  - M2M_Receiver_1.exe is the SAME file as the one checked before (identical hash), so nothing new to port.
  - Your DB\*.udb files (1184 records, Jan-Sep 2026) confirm the old format: "yyyy-MM-dd HH:mm:ss.fff|content",
    CRLF line ends, no special characters.  The new Receiver writes exactly this format (the DB Search reads the old files).
  - Difference found and FIXED: the old Receiver also wrote EMPTY messages into the DB (e.g. 31 of 32 records on
    2026-01-21, 8 on 2026-09-07). The first rebuild skipped them. Now they are logged to the DB like before
    (setting "Log empty messages to DB", default = true). No file is created for an empty message.
  - Your cfg uses CR-only line ends: handled, and the file is saved back the same way.

NEW FEATURES (all OFF / same as old by default - nothing changes until you turn them on)
  1. DB Search      Button "DB Search..." (Receiver). Pick a date or "All dates", type a text (for example a
                    GVD... barcode or a serial number), Search. Click a row to see the full message. "Export CSV..." saves
                    the result for Excel. Works on all your old .udb files.
  2. Statistics     New line under the status: messages today, time of the last message, duplicates skipped.
  3. No-data alarm  Settings > 7 > "No-data alarm (minutes)". If nothing arrives for that long: red bar + log line + beep.
                    Clears by itself when data comes again. 0 = off.
  4. Allowed IPs    Settings > 7 > "Allowed sender IPs" (comma separated). Other PCs are refused. Empty = everyone (old).
  5. Duplicate filter  Settings > 7 > "Duplicate filter (seconds)". The same text again within N seconds is not saved twice;
                    the sender still gets its ACK, so it does not retry. 0 = off (old: everything is saved).

  6. NO DATA LOSS   (always on)  Order for every message: 1) written to DB\yyyy-MM-dd.udb and flushed to disk,
                    2) saved as file in Working directory + Monitor folder. If a folder is not reachable (network drive down,
                    disk full) the file is kept in the "Pending" folder next to the exe and delivered automatically every 10 s,
                    also after a restart. The status line shows "WAITING IN PENDING: n". The DB always has the message.
                    For a guarantee up to the SENDER: turn on Auto-ACK (Receiver) + Wait for ACK with retries (Sender) and use
                    Framing = Line / StxEtx / LengthPrefix with a Checksum. Then a message is acknowledged only after it is safe.

  7. Icon           Receiver has its own icon (M2M_Receiver\\AppIcon.ico): orange rounded square, white download arrow
                    (same orange style as PDCA Sender). To use another one, replace that .ico file and build again.

OFFLINE BUILD (no internet)
  Double-click  Build_Offline.bat
    - needs only the .NET SDK installed on the PC (no NuGet download: the projects use no packages)
    - it reads your SDK version and builds for it automatically (SDK 8 -> net8.0-windows, SDK 10 -> net10.0-windows),
      so the old "NETSDK1004" problem cannot come back
    - result: ONE single exe per app, icon inside:  Output\M2M_Receiver_1.exe  and  Output\M2M_Sender.exe
      (framework-dependent single file, 64-bit Windows, nothing is downloaded)
  The line PC needs the ".NET Desktop Runtime" of the same major version (offline installer is enough).
  A fully self-contained exe (no runtime needed) must be published once on a PC WITH internet:
    dotnet publish M2M_Receiver\M2M_Receiver_1.csproj -c Release -r win-x64 --self-contained -p:PublishSingleFile=true

NOT TESTED: no .NET compiler was available where this was written. If Build_Offline.bat shows an error, send me the
error text and I will fix it.

M2M Receiver + M2M Sender  (rebuilt from the old M2M_Receiver_1.exe / M2M_Sender.exe)
=====================================================================================

FOLDERS
  Shared\         code used by both apps (cfg reader, framing/checksum, password, settings window, log box)
  M2M_Receiver\   M2M_Receiver_1.csproj   -> builds M2M_Receiver_1.exe
  M2M_Sender\     M2M_Sender.csproj       -> builds M2M_Sender.exe

BUILD (Visual Studio)
  File > Open > Project/Solution > choose M2M_Receiver\M2M_Receiver_1.csproj  > F5
  then the same for M2M_Sender\M2M_Sender.csproj
  (keep the Shared folder next to both project folders)
  If your Visual Studio / SDK uses another .NET version, change <TargetFramework> in the .csproj
  (net8.0-windows -> net10.0-windows) the same way as you did for the TCP Terminal.

  Exe for the line PC (no .NET install needed there):
    dotnet publish -c Release -r win-x64 --self-contained -p:PublishSingleFile=true

CONFIG FILES (next to the exe)
  M2M_Receiver_1.cfg and M2M_Sender.cfg. Your OLD .cfg files work as they are: copy them next to the new exe.
  Keys that are missing are added with defaults the first time you press "Save & Apply" in Settings.
  Everything can be changed in the app: Settings...  (asks for the close password).

DEFAULT BEHAVIOUR = OLD BEHAVIOUR
  Framing = None, no ACK, no auto-reply, password xyz678 -> works like the old apps.
  Turn the new features on in Settings, on BOTH sides (Sender and Receiver must use the same Framing / Checksum / ACK text).

NEW FEATURES
  1. Multiple clients   Receiver accepts many senders at the same time. Table at the top shows each sender.
                        Settings > Max clients limits it (0 = no limit).
  2. Message format     Framing: None / Line / StxEtx / LengthPrefix / Fixed.  Checksum: XOR / SUM8 / CRC16
                        (ASCII hex inside StxEtx and LengthPrefix frames). Bad checksum = message rejected + NAK.
  3. ACK                Receiver: Auto-ACK (ACK after the file is saved, NAK on error / bad checksum).
                        Sender: Wait for ACK + timeout + retries. A file in the send folder is only moved to "Sent"
                        after it was acknowledged.
  4. Auto-send          Sender: send a fixed text every N ms (tick "Auto-send" in the main window; text in Settings).
     Auto-reply         Receiver: reply with a text when a message contains a word. It switches itself off if
                        more than 200 automatic replies happen in one second (two devices answering each other).
  5. Settings save      All settings are stored in the .cfg files. Settings window = PropertyGrid. The password can
                        be changed in the app and is then stored as a hash, not as plain text.

WHAT I COULD NOT SEE IN THE OLD EXEs (no source code) - these are ASSUMPTIONS, please check:
  - Receiver saves each message as  <WorkingDirectory>\M2M_yyyyMMdd_HHmmss_fff.txt  (+ a copy in the monitor folder)
    and writes  DB\yyyy-MM-dd.udb  as  "timestamp|content".  The real old file naming may be different.
  - A message that is exactly the "M2M_CommunicationTestString" is answered but not saved.
  - Sender reads files from  M2M_Sender_SendFolder  (new key, default C:\SH\M2M_SendFolder), oldest first,
    sends the whole file as ONE message and moves it to "Sent". The old Sender may get its data another way.
  - Status line text and the "Fuzion Machine Sent To AOI:" log text are copied from the old exes.
  - Old exes were .NET Framework 4.0. These are .NET 8: the line PCs need the .NET 8 Desktop Runtime,
    or use the self-contained publish above.

QUICK TEST (one PC)
  1. Start M2M_Receiver_1.exe (127.0.0.1:1900).  2. Start M2M_Sender.exe.
  3. Put a .txt file in C:\SH\M2M_SendFolder  -> it appears in C:\SH\M2M_ReceivedFolder and in DB\<date>.udb.
  Two PCs: Receiver IP = the Receiver PC's LAN IP (or 0.0.0.0), Sender "Receiver IP address" = that same IP.
  Windows Firewall must allow the port.
