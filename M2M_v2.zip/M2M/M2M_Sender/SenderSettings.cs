using System.ComponentModel;
using M2M.Shared;

namespace M2M_Sender;

/// <summary>
/// All Sender settings. Shown in the Settings window and stored in M2M_Sender.cfg.
/// The old keys keep their old names, so an existing .cfg file works as it is.
/// </summary>
public sealed class SenderSettings
{
    // ---------- Connection ----------
    [Category("1. Connection"), DisplayName("Receiver IP address"), Description("IP address of the PC where M2M_Receiver is running.")]
    public string AoiIpAddress { get; set; } = "127.0.0.1";

    [Category("1. Connection"), DisplayName("Receiver port"), Description("Must be the same as the Port in the Receiver.")]
    public int AoiPort { get; set; } = 1900;

    [Category("1. Connection"), DisplayName("Auto-reconnect"), Description("If the connection is lost, connect again automatically.")]
    public bool AutoReconnect { get; set; } = true;

    [Category("1. Connection"), DisplayName("Reconnect delay (ms)")]
    public int ReconnectDelayMs { get; set; } = 3000;

    // ---------- Folder sending ----------
    [Category("2. Send folder"), DisplayName("Send folder"),
     Description("Files that appear here are sent to the Receiver, oldest first. After sending, a file is moved to the 'Sent' sub folder. Empty = folder sending off.")]
    public string SendFolder { get; set; } = @"C:\SH\M2M_SendFolder";

    [Category("2. Send folder"), DisplayName("File format"), Description("Only files with this extension are sent.")]
    public string SendFileFormat { get; set; } = ".txt";

    [Category("2. Send folder"), DisplayName("Timer interval (ms)"), Description("How often the send folder is checked.")]
    public int TimerInterval { get; set; } = 500;

    // ---------- Message format ----------
    [Category("3. Message format"), DisplayName("Framing"),
     Description("None = old behaviour (data is sent as it is). Line = ends with a new line. StxEtx = 0x02 ... 0x03. LengthPrefix = 2-byte length first. Fixed = always the same length. Must match the Receiver.")]
    public FramingMode Framing { get; set; } = FramingMode.None;

    [Category("3. Message format"), DisplayName("Checksum"),
     Description("Only for StxEtx and LengthPrefix. Added as ASCII hex text (XOR / SUM8 = 2 characters, CRC16 = 4). Must match the Receiver.")]
    public ChecksumMode Checksum { get; set; } = ChecksumMode.None;

    [Category("3. Message format"), DisplayName("Fixed length"), Description("Message length in bytes when Framing = Fixed.")]
    public int FixedLength { get; set; } = 16;

    [Category("3. Message format"), DisplayName("Message gap (ms)"),
     Description("Framing = None only: replies that arrive together, with no pause longer than this, are ONE reply.")]
    public int MessageGapMs { get; set; } = 200;

    // ---------- ACK ----------
    [Category("4. ACK"), DisplayName("Wait for ACK"),
     Description("After every message wait for the ACK text from the Receiver. If it does not come (or NAK comes) the message is sent again.")]
    public bool WaitAck { get; set; } = false;

    [Category("4. ACK"), DisplayName("ACK text")]
    public string AckText { get; set; } = "ACK";

    [Category("4. ACK"), DisplayName("NAK text")]
    public string NakText { get; set; } = "NAK";

    [Category("4. ACK"), DisplayName("ACK timeout (ms)")]
    public int AckTimeoutMs { get; set; } = 2000;

    [Category("4. ACK"), DisplayName("Retries"), Description("How many extra times a message is sent when there is no ACK.")]
    public int Retries { get; set; } = 3;

    // ---------- Auto-send ----------
    [Category("5. Auto-send"), DisplayName("Auto-send text"), Description("Message that is sent again and again when Auto-send is switched on in the main window.")]
    public string AutoSendText { get; set; } = "";

    [Category("5. Auto-send"), DisplayName("Auto-send interval (ms)")]
    public int AutoSendIntervalMs { get; set; } = 1000;

    // ---------- Display ----------
    [Category("6. Other"), DisplayName("Max log lines"), Description("Older lines are removed from the screen after this many.")]
    public int MaxLogLines { get; set; } = 2000;

    // ---------- load / save ----------
    public SenderSettings Clone() => (SenderSettings)MemberwiseClone();

    public static SenderSettings LoadFrom(IniConfig c)
    {
        var d = new SenderSettings();
        var s = new SenderSettings
        {
            AoiIpAddress = c.Get("M2M_AOI_IP_Address", d.AoiIpAddress),
            AoiPort = c.GetInt("M2M_AOI_Port", d.AoiPort),
            AutoReconnect = c.GetBool("M2M_Sender_AutoReconnect", d.AutoReconnect),
            ReconnectDelayMs = c.GetInt("M2M_Sender_ReconnectDelayMs", d.ReconnectDelayMs),
            SendFolder = c.Get("M2M_Sender_SendFolder", d.SendFolder),
            SendFileFormat = c.Get("M2M_Sender_FileFormat", d.SendFileFormat),
            TimerInterval = c.GetInt("M2M_Sender_TimerInterval", d.TimerInterval),
            Framing = ParseEnum(c.Get("M2M_Framing"), d.Framing),
            Checksum = ParseEnum(c.Get("M2M_Checksum"), d.Checksum),
            FixedLength = c.GetInt("M2M_FixedLength", d.FixedLength),
            MessageGapMs = c.GetInt("M2M_Sender_MessageGapMs", d.MessageGapMs),
            WaitAck = c.GetBool("M2M_WaitAck", d.WaitAck),
            AckText = c.Get("M2M_AckText", d.AckText),
            NakText = c.Get("M2M_NakText", d.NakText),
            AckTimeoutMs = c.GetInt("M2M_AckTimeoutMs", d.AckTimeoutMs),
            Retries = c.GetInt("M2M_Retries", d.Retries),
            AutoSendText = c.Get("M2M_AutoSendText", d.AutoSendText),
            AutoSendIntervalMs = c.GetInt("M2M_AutoSendIntervalMs", d.AutoSendIntervalMs),
            MaxLogLines = c.GetInt("M2M_Sender_MaxLogLines", d.MaxLogLines)
        };
        s.Normalize();
        return s;
    }

    public void SaveTo(IniConfig c)
    {
        if (!c.Has("Software_VersionInformation")) c.Set("Software_VersionInformation", "M2M Sender 2026-10-16");

        c.Set("M2M_AOI_IP_Address", AoiIpAddress);
        c.Set("M2M_AOI_Port", AoiPort);
        c.Set("M2M_Sender_AutoReconnect", AutoReconnect);
        c.Set("M2M_Sender_ReconnectDelayMs", ReconnectDelayMs);
        c.Set("M2M_Sender_SendFolder", SendFolder);
        c.Set("M2M_Sender_FileFormat", SendFileFormat);
        c.Set("M2M_Sender_TimerInterval", TimerInterval);
        c.Set("M2M_Framing", Framing.ToString());
        c.Set("M2M_Checksum", Checksum.ToString());
        c.Set("M2M_FixedLength", FixedLength);
        c.Set("M2M_Sender_MessageGapMs", MessageGapMs);
        c.Set("M2M_WaitAck", WaitAck);
        c.Set("M2M_AckText", AckText);
        c.Set("M2M_NakText", NakText);
        c.Set("M2M_AckTimeoutMs", AckTimeoutMs);
        c.Set("M2M_Retries", Retries);
        c.Set("M2M_AutoSendText", AutoSendText);
        c.Set("M2M_AutoSendIntervalMs", AutoSendIntervalMs);
        c.Set("M2M_Sender_MaxLogLines", MaxLogLines);
        c.Save();
    }

    /// <summary>Puts every value into a safe range.</summary>
    public void Normalize()
    {
        AoiIpAddress = (AoiIpAddress ?? "").Trim();
        AoiPort = Math.Min(65535, Math.Max(1, AoiPort));
        ReconnectDelayMs = Math.Min(600000, Math.Max(500, ReconnectDelayMs));
        TimerInterval = Math.Min(60000, Math.Max(50, TimerInterval));
        FixedLength = Math.Min(65535, Math.Max(1, FixedLength));
        MessageGapMs = Math.Min(60000, Math.Max(10, MessageGapMs));
        AckTimeoutMs = Math.Min(600000, Math.Max(100, AckTimeoutMs));
        Retries = Math.Min(100, Math.Max(0, Retries));
        AutoSendIntervalMs = Math.Min(3600000, Math.Max(50, AutoSendIntervalMs));
        MaxLogLines = Math.Min(100000, Math.Max(100, MaxLogLines));
        SendFileFormat = Util.NormalizeExt(SendFileFormat);
        SendFolder ??= "";
        AckText ??= "";
        NakText ??= "";
        AutoSendText ??= "";
    }

    private static T ParseEnum<T>(string text, T def) where T : struct, Enum
        => Enum.TryParse<T>(text, true, out var v) && Enum.IsDefined(typeof(T), v) ? v : def;
}
