@echo off
setlocal enableextensions
cd /d "%~dp0"
title M2M - offline build

rem ------------------------------------------------------------------
rem  Builds M2M_Receiver_1.exe and M2M_Sender.exe WITHOUT internet.
rem  The projects use no NuGet packages, so only the .NET SDK is needed
rem  (installed once; it already contains everything the build needs).
rem  Result: ONE exe file for each app (icon inside):
rem     Output\M2M_Receiver_1.exe   and   Output\M2M_Sender.exe
rem ------------------------------------------------------------------

where dotnet >nul 2>&1
if errorlevel 1 (
  echo.
  echo  .NET SDK not found on this PC.
  echo  Install the .NET SDK once ^(offline installer from another PC is fine^), then run this file again.
  echo.
  pause
  exit /b 1
)

set SDKMAJOR=
for /f "tokens=1 delims=." %%v in ('dotnet --version') do set SDKMAJOR=%%v
if "%SDKMAJOR%"=="" (
  echo  Could not read the SDK version.
  pause
  exit /b 1
)
set TFM=net%SDKMAJOR%.0-windows
echo  .NET SDK major version: %SDKMAJOR%   -^>  target: %TFM%
echo  (the line PC needs the matching ".NET Desktop Runtime %SDKMAJOR%" installed)
echo.

rem an empty local folder as the only NuGet source = nothing is downloaded
if not exist "%~dp0_offline_nuget" mkdir "%~dp0_offline_nuget"
if exist "%~dp0Output" rmdir /s /q "%~dp0Output"

call :build M2M_Receiver M2M_Receiver_1
if errorlevel 1 goto :failed
call :build M2M_Sender M2M_Sender
if errorlevel 1 goto :failed

echo.
echo  ============================================================
echo   DONE.  One single exe per app, with icon:
echo     %~dp0Output\M2M_Receiver_1.exe
echo     %~dp0Output\M2M_Sender.exe
echo   Copy the exe to the line PC. The .cfg and DB folder are created next to it
echo   ^(or copy your old M2M_Receiver_1.cfg / M2M_Sender.cfg and the DB folder next to the exe^).
echo  ============================================================
echo.
pause
exit /b 0

:build
echo  ---- building %2 ----
dotnet publish "%~dp0%1\%2.csproj" -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -p:DebugType=none -p:DebugSymbols=false -p:TargetFramework=%TFM% -p:NuGetAudit=false --source "%~dp0_offline_nuget" -o "%~dp0Output"
exit /b %errorlevel%

:failed
echo.
echo  BUILD FAILED. Copy the error text above and send it to me.
echo.
pause
exit /b 1
