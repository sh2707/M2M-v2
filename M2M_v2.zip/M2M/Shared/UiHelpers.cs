namespace M2M.Shared;

/// <summary>Black, cmd-style log box with a max-lines limit (so the app never gets slow).</summary>
public sealed class LogBox : TextBox
{
    private int lines;

    public int MaxLines { get; set; } = 2000;

    public LogBox()
    {
        Multiline = true;
        ReadOnly = true;
        ScrollBars = ScrollBars.Vertical;
        WordWrap = true;
        Font = new Font("Consolas", 10);
        BackColor = Color.FromArgb(12, 12, 12);
        ForeColor = Color.LightGray;
    }

    public void AddLine(string text)
    {
        if (IsDisposed) return;

        string fixedText = text.Replace("\r\n", "\n").Replace("\n", "\r\n");
        AppendText($"[{DateTime.Now:HH:mm:ss}] {fixedText}\r\n");
        lines += 1 + CountNewLines(fixedText);

        if (lines > MaxLines + 100)
        {
            string[] all = Lines;
            int skip = Math.Max(0, all.Length - MaxLines);
            Text = string.Join("\r\n", all.Skip(skip));
            lines = Math.Min(MaxLines, all.Length);
            SelectionStart = TextLength;
            ScrollToCaret();
        }
    }

    public new void Clear()
    {
        base.Clear();
        lines = 0;
    }

    private static int CountNewLines(string s)
    {
        int n = 0;
        foreach (char c in s) if (c == '\n') n++;
        return n;
    }
}

/// <summary>Generic settings window: shows all public properties of an object in a PropertyGrid.</summary>
public sealed class SettingsForm : Form
{
    public SettingsForm(object settingsCopy, string title)
    {
        Text = title;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(560, 640);
        MinimizeBox = false;
        MaximizeBox = false;
        ShowInTaskbar = false;

        var grid = new PropertyGrid
        {
            Dock = DockStyle.Fill,
            SelectedObject = settingsCopy,
            HelpVisible = true,
            ToolbarVisible = false,
            PropertySort = PropertySort.Categorized
        };

        var bar = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 46,
            FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(8)
        };
        var save = new Button { Text = "Save && Apply", Width = 110, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "Cancel", Width = 80, DialogResult = DialogResult.Cancel };
        bar.Controls.Add(cancel);
        bar.Controls.Add(save);

        Controls.Add(grid);
        Controls.Add(bar);
        AcceptButton = save;
        CancelButton = cancel;
    }
}

public static class Util
{
    /// <summary>One-line, shortened version of a message for the log.</summary>
    public static string OneLine(string s, int max = 300)
    {
        string t = s.Replace("\r", "").Replace("\n", " | ").Trim();
        return t.Length <= max ? t : t.Substring(0, max) + " ...";
    }

    public static string NormalizeExt(string ext, string def = ".txt")
    {
        ext = (ext ?? "").Trim();
        if (ext.Length == 0) return def;
        return ext.StartsWith(".") ? ext : "." + ext;
    }
}
